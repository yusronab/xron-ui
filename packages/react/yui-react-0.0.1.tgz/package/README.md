# @yui/react

React component library built with TypeScript and Tailwind CSS.

## Installation

```bash
npm install @yui/react
```

## Usage

Import Css:

```bash
import "@yui/react/styles.css";
```

Import components:

```bash
import { Button, Input } from "@yui/react";
```

Example:

```bash
import "@yui/react/styles.css";

import { Button, Input } from "@yui/react";

function App() {
  return (
    <div>
      <Button>
        Submit
      </Button>

      <Input
        placeholder="Email"
      />
    </div>
  );
}

export default App;
```